
document.addEventListener("DOMContentLoaded", function() {
    console.log("HygienExperts Website Loaded Successfully");
});
